# Telegram Task Bot

Документация проекта. Подробности в README_INSTALL.md